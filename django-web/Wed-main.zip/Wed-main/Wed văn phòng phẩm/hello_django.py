"""
Django Hello World Application
"""

print("✅ Django Web Development Setup Complete!")
print("\n📝 Tạo Django project mới:")
print("   $ cd python-projects\\django-web")
print("   $ django-admin startproject config .")
print("   $ django-admin startapp myapp")
print("   $ python manage.py runserver")
print("\n🔗 Truy cập: http://localhost:8000")
