from django.contrib import admin
from .models import Category, Product, Order

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'created_at']
    search_fields = ['name']
    
    fieldsets = (
        ('📂 Thông tin danh mục', {
            'fields': ('name',)
        }),
    )


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['name', 'price', 'category', 'stock', 'created_at']
    list_filter = ['category', 'created_at']
    search_fields = ['name', 'description']
    
    fieldsets = (
        ('📦 Thông tin cơ bản', {
            'fields': ('name', 'category', 'price', 'stock')
        }),
        ('📝 Chi tiết mô tả', {
            'fields': ('description', 'image')
        }),
    )


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['id', 'customer_name', 'phone', 'total_price', 'created_at']
    list_filter = ['created_at']
    search_fields = ['customer_name', 'phone', 'address']
    readonly_fields = ['created_at', 'total_price', 'id']
    
    def get_fieldsets(self, request, obj=None):
        if obj:  # Editing an existing object
            return (
                ('Thông tin đơn hàng', {
                    'fields': ('id', 'created_at', 'total_price')
                }),
                ('Thông tin khách hàng', {
                    'fields': ('customer_name', 'phone', 'address')
                }),
            )
        else:  # Adding a new object
            return (
                ('Thông tin khách hàng', {
                    'fields': ('customer_name', 'phone', 'address', 'total_price')
                }),
            )
