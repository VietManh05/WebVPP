from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Product, Category, Order
from decimal import Decimal


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def get_cart_from_session(request):
    """Lấy giỏ hàng từ session và chuyển đổi key thành string"""
    cart = request.session.get('cart', {})
    return {str(k): v for k, v in cart.items()}


def save_cart_to_session(request, cart):
    """Lưu giỏ hàng vào session"""
    request.session['cart'] = cart
    request.session.modified = True


def calculate_cart_totals(cart):
    """
    Tính toán tổng giá và danh sách sản phẩm từ giỏ hàng.
    
    Returns:
        tuple: (cart_items list, total_price Decimal)
    """
    cart_items = []
    total_price = Decimal('0')
    
    for product_id_str, quantity in cart.items():
        product = get_object_or_404(Product, id=int(product_id_str))
        subtotal = product.price * quantity
        
        cart_items.append({
            'product': product,
            'quantity': quantity,
            'subtotal': subtotal,
        })
        total_price += subtotal
    
    return cart_items, total_price


def clear_cart_session(request):
    """Xóa giỏ hàng trong session"""
    request.session['cart'] = {}
    request.session.modified = True


# ============================================================
# HOME & PRODUCT VIEWS
# ============================================================

def home(request):
    """Hiển thị danh sách sản phẩm với lọc theo danh mục"""
    categories = Category.objects.all()
    category_id = request.GET.get('category')
    
    # Lọc sản phẩm theo danh mục nếu có
    if category_id:
        products = Product.objects.filter(category_id=category_id)
    else:
        products = Product.objects.all()
    
    context = {
        'products': products,
        'categories': categories,
        'selected_category': category_id,
    }
    return render(request, 'home.html', context)


def product_detail(request, id):
    """Hiển thị chi tiết sản phẩm"""
    product = get_object_or_404(Product, id=id)
    return render(request, 'product_detail.html', {'product': product})


# ============================================================
# SHOPPING CART VIEWS
# ============================================================

def add_to_cart(request, product_id):
    """Thêm sản phẩm vào giỏ hàng"""
    cart = get_cart_from_session(request)
    product_id_str = str(product_id)
    
    # Tăng số lượng hoặc thêm mới
    cart[product_id_str] = cart.get(product_id_str, 0) + 1
    save_cart_to_session(request, cart)
    
    return redirect(request.META.get('HTTP_REFERER', 'home'))


def remove_from_cart(request, product_id):
    """Xóa sản phẩm khỏi giỏ hàng"""
    cart = get_cart_from_session(request)
    product_id_str = str(product_id)
    
    if product_id_str in cart:
        del cart[product_id_str]
        save_cart_to_session(request, cart)
    
    return redirect('cart')


def update_cart(request, product_id):
    """Cập nhật số lượng sản phẩm trong giỏ hàng"""
    if request.method != 'POST':
        return redirect('cart')
    
    quantity = int(request.POST.get('quantity', 1))
    cart = get_cart_from_session(request)
    product_id_str = str(product_id)
    
    if quantity > 0:
        cart[product_id_str] = quantity
    elif product_id_str in cart:
        del cart[product_id_str]
    
    save_cart_to_session(request, cart)
    return redirect('cart')


def cart_view(request):
    """Hiển thị trang giỏ hàng"""
    cart = get_cart_from_session(request)
    cart_items, total_price = calculate_cart_totals(cart)
    
    context = {
        'cart_items': cart_items,
        'total_price': total_price,
        'cart_count': len(cart),
    }
    return render(request, 'cart.html', context)


# ============================================================
# CHECKOUT VIEWS
# ============================================================

def checkout(request):
    """Xử lý thanh toán"""
    cart = get_cart_from_session(request)
    
    # Kiểm tra giỏ hàng không trống
    if not cart:
        messages.warning(request, 'Giỏ hàng của bạn trống!')
        return redirect('home')
    
    # POST: Tạo đơn hàng
    if request.method == 'POST':
        return _create_order(request, cart)
    
    # GET: Hiển thị form thanh toán
    cart_items, total_price = calculate_cart_totals(cart)
    context = {
        'cart_items': cart_items,
        'total_price': total_price,
    }
    return render(request, 'checkout.html', context)


def _create_order(request, cart):
    """
    Helper function: Tạo đơn hàng từ giỏ hàng.
    
    Args:
        request: Django request object
        cart: Dictionary giỏ hàng
    
    Returns:
        redirect: Chuyển hướng đến trang xác nhận
    """
    # Lấy thông tin từ form
    customer_name = request.POST.get('name', '').strip()
    phone = request.POST.get('phone', '').strip()
    address = request.POST.get('address', '').strip()
    
    # Validate dữ liệu cơ bản
    if not all([customer_name, phone, address]):
        messages.error(request, 'Vui lòng điền đầy đủ thông tin!')
        return redirect('checkout')
    
    # Tính tổng giá
    _, total_price = calculate_cart_totals(cart)
    
    # Tạo đơn hàng
    Order.objects.create(
        customer_name=customer_name,
        phone=phone,
        address=address,
        total_price=total_price,
    )
    
    # Xóa giỏ hàng
    clear_cart_session(request)
    messages.success(request, 'Đặt hàng thành công! Cảm ơn bạn!')
    
    return redirect('checkout_success')


def checkout_success(request):
    """Hiển thị trang xác nhận đặt hàng thành công"""
    return render(request, 'checkout_success.html')
